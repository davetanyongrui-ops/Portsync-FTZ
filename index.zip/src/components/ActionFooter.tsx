import { Braces, FileCode } from "lucide-react";
import type { DeclarationTotals } from "../types";
import { fmtIdr, fmtIdrShort } from "../lib/format";
import { Btn, Pill } from "./ui";

function Stat({ label, value, tone = "default" }: { label: string; value: string; tone?: "default" | "good" | "warn" }) {
  return (
    <div className="leading-tight">
      <div className="text-[11px] font-medium tracking-wider text-zinc-500 uppercase">{label}</div>
      <div
        className={
          tone === "good"
            ? "tnum mt-1 text-[13px] font-semibold text-emerald-400"
            : tone === "warn"
              ? "tnum mt-1 text-[13px] font-semibold text-amber-400"
              : "tnum mt-1 text-[13px] font-semibold text-zinc-100"
        }
      >
        {value}
      </div>
    </div>
  );
}

export function ActionFooter({
  totals,
  ready,
  onDownloadXml,
  onOpenPayload,
}: {
  totals: DeclarationTotals;
  ready: boolean;
  onDownloadXml: () => void;
  onOpenPayload: () => void;
}) {
  const filed = ready && totals.selected > 0;

  return (
    <div className="flex shrink-0 flex-wrap items-center gap-x-8 gap-y-4 rounded-xl border border-zinc-800 bg-zinc-900/50 px-5 py-4">
      <Stat label="Lines filed" value={ready ? `${totals.selected}/${totals.lines}` : "—"} />
      <Stat
        label="Payable"
        value={filed ? fmtIdr(totals.payable) : "—"}
        tone={filed ? (totals.payable === 0 ? "good" : "warn") : "default"}
      />
      <Stat label="FTZ saving" value={filed ? fmtIdrShort(totals.saved) : "—"} tone={filed ? "good" : "default"} />
      <div className="hidden sm:block">
        <Stat label="Avg match" value={filed ? `${Math.round(totals.avgConfidence * 100)}%` : "—"} />
      </div>
      {filed && totals.blocked > 0 && (
        <Pill tone="bad" title="Pre-border Lartas lines must carry a permit number before the PIB can be submitted.">
          {totals.blocked} blocked
        </Pill>
      )}

      <div className="ml-auto flex items-center gap-3">
        <Btn icon={FileCode} onClick={onDownloadXml} disabled={!filed} title="CEISA-flavoured interchange document">
          Download CEISA-Ready XML
        </Btn>
        <Btn variant="primary" icon={Braces} onClick={onOpenPayload} disabled={!filed}>
          Generate PPFTZ-01 Declaration Payload
        </Btn>
      </div>
    </div>
  );
}
