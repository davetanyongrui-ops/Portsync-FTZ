import { ArrowRight, Check, ChevronDown, FileSearch, RotateCcw, Sparkles, TriangleAlert } from "lucide-react";
import type { DemoInvoice, LineCalc } from "../types";
import { DEMO_INVOICES } from "../data/fixtures";
import { fmtDate } from "../lib/format";
import { cn } from "../lib/cn";
import { Btn, Label, Pill } from "./ui";
import { InvoicePage } from "./InvoicePage";
import type { UploadedFile } from "./UploadZone";
import { UploadZone } from "./UploadZone";

export const PIPELINE = [
  "Normalising page geometry",
  "Detecting line-item regions",
  "Reading supplier grammar + totals",
  "Mapping descriptions to BTKI HS",
  "Applying PPFTZ-01 facility rules",
];

export type AnalyzeState = "staged" | "analyzing" | "ready";

export function LeftPanel({
  invoice,
  invoiceId,
  onPick,
  uploaded,
  onUpload,
  onClearUpload,
  onReject,
  status,
  stage,
  calcs,
  activeId,
  onActive,
  onAnalyze,
  onReset,
}: {
  invoice: DemoInvoice;
  invoiceId: string;
  onPick: (id: string) => void;
  uploaded: UploadedFile | null;
  onUpload: (f: UploadedFile) => void;
  onClearUpload: () => void;
  onReject: (message: string) => void;
  status: AnalyzeState;
  stage: number;
  calcs: LineCalc[];
  activeId: string | null;
  onActive: (id: string | null) => void;
  onAnalyze: () => void;
  onReset: () => void;
}) {
  const analyzed = status === "ready";

  return (
    <section className="scroll-thin flex h-full min-h-0 w-full flex-col gap-4 overflow-y-auto p-5">
      <div className="flex shrink-0 items-center gap-2.5">
        <FileSearch size={16} className="shrink-0 text-cyan-400" />
        <h2 className="truncate text-[13.5px] font-semibold tracking-tight text-white">
          Document &amp; Source Inspector
        </h2>
        <div className="ml-auto shrink-0">
          {status === "staged" && <Pill tone="mut">Awaiting analysis</Pill>}
          {status === "analyzing" && <Pill tone="brand">Agent running</Pill>}
          {status === "ready" && <Pill tone="good">Parsed · {calcs.length} lines</Pill>}
        </div>
      </div>

      <div className="shrink-0 space-y-4">
        <UploadZone file={uploaded} onFile={onUpload} onClear={onClearUpload} onReject={onReject} />

        <div>
          <Label className="mb-2">Demo Invoices</Label>
          <div className="relative">
            <select
              id="demo-invoice"
              value={invoiceId}
              onChange={(e) => onPick(e.target.value)}
              className="h-10 w-full cursor-pointer appearance-none rounded-lg border border-zinc-700 bg-zinc-900 px-3 pr-9 text-[13px] text-zinc-200 transition-colors hover:border-zinc-600"
              aria-label="Select a preloaded demo invoice"
            >
              {DEMO_INVOICES.map((inv) => (
                <option key={inv.id} value={inv.id}>
                  {inv.label}
                </option>
              ))}
            </select>
            <ChevronDown size={14} className="pointer-events-none absolute top-3 right-3 text-zinc-500" />
          </div>

          <div className="mt-3 rounded-lg border border-zinc-800/80 bg-zinc-900/40 p-3.5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate text-[13px] font-semibold text-zinc-100">{invoice.supplier.name}</div>
                <div className="mt-1 flex flex-wrap items-center gap-x-1.5 text-[11.5px] text-zinc-400">
                  {invoice.consignee.name}
                  <ArrowRight size={11} className="text-zinc-600" />
                  <span className="text-zinc-500">KPBPB Batam</span>
                </div>
              </div>
              <Pill tone="brand" className="shrink-0">
                {invoice.currency}
              </Pill>
            </div>
            <div className="tnum mt-2.5 flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-zinc-800/70 pt-2.5 text-[11.5px] text-zinc-500">
              <span>{invoice.docNo}</span>
              <span className="text-zinc-700">·</span>
              <span>{fmtDate(invoice.docDate)}</span>
              <span className="text-zinc-700">·</span>
              <span>ETA {fmtDate(invoice.freight.eta)}</span>
              <span className="text-zinc-700">·</span>
              <span>{invoice.lines.length} line items</span>
            </div>
            <p className="mt-2.5 text-[12px] leading-relaxed text-zinc-400 italic">{invoice.headline}</p>
          </div>
        </div>

        {uploaded && (
          <div className="flex items-start gap-2.5 rounded-lg border border-amber-500/25 bg-amber-500/8 px-3.5 py-3 text-[11.5px] leading-relaxed text-amber-300/90">
            <TriangleAlert size={14} className="mt-px shrink-0 text-amber-400" />
            <span>
              <b className="font-semibold text-amber-200">{uploaded.name}</b> is staged locally. This build ships no OCR
              backend, so the agent parses it against the{" "}
              <b className="font-semibold text-amber-200">{invoice.label.split(" — ")[0]}</b> fixture grammar and reports
              those values.
            </span>
          </div>
        )}

        {status === "analyzing" && (
          <ul className="animate-rise space-y-1.5 rounded-lg border border-zinc-800/80 bg-zinc-900/40 p-3.5">
            {PIPELINE.map((s, i) => (
              <li
                key={s}
                className={cn(
                  "flex items-center gap-2.5 text-[11.5px] transition-colors",
                  i < stage ? "text-emerald-400" : i === stage ? "text-cyan-400" : "text-zinc-600",
                )}
              >
                <span
                  className={cn(
                    "grid size-4 shrink-0 place-items-center rounded-full border",
                    i < stage
                      ? "border-emerald-500/50 bg-emerald-500/15"
                      : i === stage
                        ? "animate-blip border-cyan-500/60 bg-cyan-500/15"
                        : "border-zinc-700",
                  )}
                >
                  {i < stage ? <Check size={9} strokeWidth={3.2} /> : null}
                </span>
                {s}
              </li>
            ))}
          </ul>
        )}
      </div>

      <InvoicePage
        invoice={invoice}
        calcs={calcs}
        analyzed={analyzed}
        analyzing={status === "analyzing"}
        activeId={activeId}
        onActive={onActive}
      />

      <div className="shrink-0 space-y-2.5 pt-1">
        <Btn
          variant="primary"
          block
          size="md"
          icon={Sparkles}
          onClick={onAnalyze}
          disabled={status === "analyzing"}
          className="h-11 text-[13.5px]"
        >
          {status === "analyzing"
            ? "Agent working…"
            : analyzed
              ? "Re-analyze & Map to BTKI Tariff"
              : "Analyze & Map to BTKI Tariff"}
        </Btn>

        <div className="flex items-center justify-between gap-3 text-[11.5px] text-zinc-500">
          <span>Reference BTKI register · deterministic, zero-latency</span>
          {analyzed && (
            <button
              type="button"
              onClick={onReset}
              className="inline-flex shrink-0 items-center gap-1.5 text-zinc-400 transition-colors hover:text-zinc-100"
            >
              <RotateCcw size={11} /> Reset overrides
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
