import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Braces, Copy, Download, FileCode, X } from "lucide-react";
import { copyText, downloadText } from "../lib/download";
import { cn } from "../lib/cn";
import { Btn, Pill, type Tone } from "./ui";

const JSON_TOKEN =
  /("(?:[^"\\]|\\.)*")(?=\s*:)|("(?:[^"\\]|\\.)*")|(-?\b\d+(?:\.\d+)?\b)|\b(true|false|null)\b/g;

const XML_TOKEN = /(<\/?[A-Za-z0-9:._-]+)|("[^"]*")|((?:[A-Za-z-]+)=)|(<!--[\s\S]*?-->)/g;

function tokenize(line: string, kind: "json" | "xml"): ReactNode[] {
  const out: ReactNode[] = [];
  const re = kind === "json" ? new RegExp(JSON_TOKEN.source, "g") : new RegExp(XML_TOKEN.source, "g");
  let last = 0;
  let n = 0;
  for (const m of line.matchAll(re)) {
    const at = m.index ?? 0;
    if (at < last) continue;
    if (at > last) out.push(line.slice(last, at));
    const cls =
      kind === "json"
        ? m[1] !== undefined
          ? "text-cyan-300"
          : m[2] !== undefined
            ? "text-emerald-300"
            : m[3] !== undefined
              ? "text-amber-300"
              : "text-violet-300"
        : m[1] !== undefined
          ? "text-cyan-300"
          : m[2] !== undefined
            ? "text-emerald-300"
            : m[3] !== undefined
              ? "text-violet-300"
              : "text-zinc-500";
    out.push(
      <span key={`${n}-${at}`} className={cls}>
        {m[0]}
      </span>,
    );
    n += 1;
    last = at + m[0].length;
  }
  if (last < line.length) out.push(line.slice(last));
  return out;
}

function CodeBlock({ text, kind }: { text: string; kind: "json" | "xml" }) {
  const lines = useMemo(() => text.split("\n"), [text]);
  return (
    <div className="scroll-thin min-h-0 flex-1 overflow-auto rounded-lg border border-zinc-800 bg-zinc-950">
      <div className="font-mono text-[12px] leading-[1.7]">
        {lines.map((l, i) => (
          <div key={i} className="grid grid-cols-[44px_1fr] hover:bg-zinc-900/70">
            <span className="tnum sticky left-0 bg-zinc-950 px-2.5 text-right text-zinc-600 select-none">{i + 1}</span>
            <span className="whitespace-pre pr-5 text-zinc-400">{tokenize(l, kind)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export interface ModalPayload {
  json: string;
  xml: string;
  fileNameBase: string;
  key: string;
  status: "PASS" | "PASS_WITH_WARNINGS" | "READY_WITH_BLOCKERS";
  blocking: number;
  warnings: number;
  payableLabel: string;
  savedLabel: string;
}

const STATUS_TONE: Record<ModalPayload["status"], Tone> = {
  PASS: "good",
  PASS_WITH_WARNINGS: "warn",
  READY_WITH_BLOCKERS: "bad",
};

export function PayloadModal({
  payload,
  onClose,
  onCopied,
}: {
  payload: ModalPayload;
  onClose: () => void;
  onCopied: (ok: boolean, label: string) => void;
}) {
  const [tab, setTab] = useState<"json" | "xml">("json");
  const text = tab === "json" ? payload.json : payload.xml;
  const bytes = useMemo(() => new Blob([text]).size, [text]);
  const lineCount = useMemo(() => text.split("\n").length, [text]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 p-6 backdrop-blur-sm"
      onClick={onClose}
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="PPFTZ-01 declaration payload"
        onClick={(e) => e.stopPropagation()}
        className="animate-pop flex h-full max-h-[min(780px,92vh)] w-full max-w-[960px] flex-col overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900 shadow-[0_40px_120px_-32px_rgba(0,0,0,0.9)]"
      >
        <div className="flex items-start gap-4 border-b border-zinc-800 px-5 py-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-lg border border-zinc-800 bg-zinc-950 text-cyan-400">
            <Braces size={18} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2.5">
              <h3 className="text-[14px] font-semibold tracking-tight text-white">
                PPFTZ-01 Declaration Payload — validated
              </h3>
              <Pill tone={STATUS_TONE[payload.status]}>{payload.status}</Pill>
            </div>
            <div className="tnum mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11.5px] text-zinc-500">
              <span>schema PPFTZ-01/4.2</span>
              <span>idempotency {payload.key}</span>
              <span className="text-emerald-400">saving {payload.savedLabel}</span>
              <span className={payload.payableLabel === "Rp 0" ? "text-emerald-400" : "text-amber-400"}>
                payable {payload.payableLabel}
              </span>
              <span>
                {payload.blocking} blocking · {payload.warnings} warnings
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid size-8 shrink-0 place-items-center rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-500 transition-colors hover:border-zinc-700 hover:text-zinc-200"
            aria-label="Close payload"
          >
            <X size={14} />
          </button>
        </div>

        <div className="flex shrink-0 items-center gap-1.5 border-b border-zinc-800 bg-zinc-950/60 px-4 py-2">
          {(
            [
              ["json", "Declaration JSON", Braces],
              ["xml", "CEISA Interchange XML", FileCode],
            ] as const
          ).map(([k, label, Icon]) => (
            <button
              key={k}
              type="button"
              onClick={() => setTab(k)}
              className={cn(
                "inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-[12.5px] font-medium transition-colors",
                tab === k ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300",
              )}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
          <div className="tnum ml-auto text-[11.5px] text-zinc-500">
            {lineCount.toLocaleString("en-US")} lines · {(bytes / 1024).toFixed(1)} KB · UTF-8
          </div>
        </div>

        <div className="flex min-h-0 flex-1 flex-col p-4">
          <CodeBlock text={text} kind={tab} />
          <p className="mt-3 shrink-0 text-[11.5px] leading-relaxed text-zinc-500">
            Generated locally by the PortSync agent against the reference BTKI register. Nothing has been transmitted to
            a customs system — verify live BTKI, INATRADE and kurs pabean values before filing.
          </p>
        </div>

        <div className="flex shrink-0 items-center gap-3 border-t border-zinc-800 bg-zinc-950/60 px-4 py-3.5">
          <Btn
            variant="ghost"
            size="sm"
            icon={Download}
            onClick={() =>
              downloadText(
                `${payload.fileNameBase}.${tab === "json" ? "json" : "xml"}`,
                text,
                tab === "json" ? "application/json" : "application/xml",
              )
            }
          >
            Download {tab === "json" ? "JSON" : "XML"}
          </Btn>
          <div className="ml-auto flex items-center gap-3">
            <Btn size="sm" variant="secondary" onClick={onClose}>
              Close
            </Btn>
            <Btn
              size="sm"
              variant="primary"
              icon={Copy}
              onClick={async () => {
                const ok = await copyText(text);
                onCopied(ok, `${tab === "json" ? "PPFTZ-01 JSON" : "CEISA XML"} payload`);
              }}
            >
              Copy to clipboard
            </Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
