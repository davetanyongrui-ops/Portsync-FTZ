import { ListChecks, Radar, Table2 } from "lucide-react";
import type { DeclarationTotals, DemoInvoice, LineCalc } from "../types";
import { KpiRow } from "./KpiRow";
import { DeclarationTable } from "./DeclarationTable";
import { ActionFooter } from "./ActionFooter";
import { Btn, Label, Pill } from "./ui";

export function RightPanel({
  invoice,
  calcs,
  totals,
  ready,
  selectedIds,
  activeId,
  onActive,
  onToggle,
  onSelectAll,
  onOverride,
  onDownloadXml,
  onOpenPayload,
}: {
  invoice: DemoInvoice;
  calcs: LineCalc[];
  totals: DeclarationTotals;
  ready: boolean;
  selectedIds: Set<string>;
  activeId: string | null;
  onActive: (id: string | null) => void;
  onToggle: (id: string) => void;
  onSelectAll: (on: boolean) => void;
  onOverride: (id: string, hs: string) => void;
  onDownloadXml: () => void;
  onOpenPayload: () => void;
}) {
  const overrides = calcs.filter((c) => c.overridden).length;
  const allSelected = ready && calcs.every((c) => selectedIds.has(c.id));

  return (
    <section className="scroll-thin flex h-full min-h-0 w-full flex-col gap-4 overflow-y-auto p-5 lg:overflow-hidden lg:p-6">
      <div className="flex shrink-0 flex-wrap items-center gap-2.5">
        <Radar size={16} className="shrink-0 text-cyan-400" />
        <h2 className="truncate text-[13.5px] font-semibold tracking-tight text-white">
          Agent Output &amp; Declaration Engine
        </h2>
        <Pill tone="mut" title="Reference register, deterministic output. No CEISA dispatch.">
          SIMULATED
        </Pill>
        <div className="ml-auto flex items-center gap-3">
          {overrides > 0 && <Pill tone="warn">{overrides} HS override{overrides > 1 ? "s" : ""}</Pill>}
          <span className="tnum hidden text-[11.5px] text-zinc-500 md:inline">{invoice.docNo}</span>
          <Btn size="sm" variant="ghost" onClick={() => onSelectAll(!allSelected)} disabled={!ready}>
            {allSelected ? "Deselect all" : "Select all"}
          </Btn>
        </div>
      </div>

      <KpiRow invoice={invoice} totals={totals} calcs={calcs} ready={ready} />

      <div className="flex shrink-0 items-center gap-3 pt-1">
        <Label className="inline-flex items-center gap-2 whitespace-nowrap text-zinc-300">
          <Table2 size={12} />
          Interactive Customs Declaration
        </Label>
        <div className="h-px flex-1 bg-zinc-800/70" />
        <span className="hidden items-center gap-1.5 whitespace-nowrap text-[11.5px] text-zinc-500 lg:flex">
          <ListChecks size={12} />
          click a row to locate it in the document
        </span>
      </div>

      <DeclarationTable
        calcs={calcs}
        selectedIds={selectedIds}
        activeId={activeId}
        ready={ready}
        onActive={onActive}
        onToggle={onToggle}
        onSelectAll={onSelectAll}
        onOverride={onOverride}
      />

      <ActionFooter totals={totals} ready={ready} onDownloadXml={onDownloadXml} onOpenPayload={onOpenPayload} />
    </section>
  );
}
